const {ipcRenderer} = require('electron')
function shareData(){
  ipcRenderer.send("msg", "Hello from render process");
  ipcRenderer.on("reply", (event, data)=>{
    alert(data);
  })
}


