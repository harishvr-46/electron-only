const { app, BrowserWindow, ipcMain, Notification, Menu, dialog } = require('electron');
const { autoUpdater } = require('electron-updater');
const path = require('path');
const { nextTick } = require('process');

ipcMain.on("msg", (event, data)=>{
  console.log(data);
  event.reply("reply", "This is data being sent from the main process to the renderer process");

})

let mainWindow;
// Creating window
function createWindow () {
  mainWindow = new BrowserWindow({
    icon: "logo.ico",
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false
    },
  });

  function setMainMenu() {
    const template = [
      {
        label: 'Home',
        accelerator: 'Shift+ctrl+h',
        click(){
          mainWindow.loadURL(`file://${path.join(__dirname, './index.html')}`); 
        }
      },
      {
        label: 'Edit'
      }
    ];
    Menu.setApplicationMenu(Menu.buildFromTemplate(template));
  }

  mainWindow.maximize();
  mainWindow.webContents.openDevTools();

  mainWindow.loadURL(`file://${path.join(__dirname, './index.html')}`);
  // mainWindow.loadURL('http://192.168.2.160:5000')

  setMainMenu();
  mainWindow.on('closed', function () {
    mainWindow = null;
  });
  mainWindow.once('ready-to-show', () => {
    autoUpdater.checkForUpdatesAndNotify();
  })
}

function tick(){
  var hours = new Date().getHours();
  var min = new Date().getMinutes();
  var sec = new Date().getSeconds();
  var ampm = hours >= 12 ? 'PM' : 'AM';

  if((hours == 11 && min==0 && sec==0 )|| hours == 15 || hours == 16){
    console.log("Time to take an Oath");
    showModal = ()=>{
      let modal = new BrowserWindow({show: false})
      modal.maximize();
      modal.on('close', ()=>{modal = null});
      modal.loadURL(`file://${path.join(__dirname, './timer.html')}`);
      modal.once('ready-to-show', ()=>{modal.show()})
    }

    showNotification = ()=>{
      var title = `Oath Time Starts in 10 seconds`;
      var body = `It's 11:00 AM. Please be ready and stand Up on Your Place. Thank You.`
      startNotification = new Notification({
        title: title, 
        body: body,
        timeoutType: 'default'
      });
      startNotification.show();
    }
    showNotification();

    setTimeout(showModal, 10000);
  }
}

ipcMain.on('click', (event, msg)=>{
    console.log(msg)
})
app.whenReady().then(createWindow).then(tick);

app.on('ready', ()=>{
  autoUpdater.on('update-available', () => {
    mainWindow.webContents.send('update_available');
    var NOTIFICATION_TITLE = `New version is available.`
    var NOTIFICATION_BODY = `App will be downloaded Automatically.`
    availableNotification = new Notification({
      title: NOTIFICATION_TITLE,
      body: NOTIFICATION_BODY,
      timeoutType: 'default',
      icon: path.join(__dirname, '/logo.ico')
    });
    availableNotification.show();
  });
})


app.on('window-all-closed', function () {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});
app.on('activate', function () {
  if (mainWindow === null) {
    createWindow();
  }
});

ipcMain.on('app_version', (event) => {
    event.sender.send('app_version', { version: app.getVersion() });
});



autoUpdater.on('update-downloaded', () => {
  var options = {
    type: 'question',
    buttons: ['OK', 'No'],
    title: 'Confirm Install',
    // normalizeAccessKeys: true,
    message: 'Update is downloaded. Do you want to Update Now?'
};
  const win = BrowserWindow.getFocusedWindow();
  dialog.showMessageBox(win, options)
    .then((choice) => {
        if (choice.response === 0) {
            autoUpdater.quitAndInstall()
        }else{
          message= `Update will automatically installed on next start.`;
        }
    }).catch(err => {
        console.log('ERROR', err);
    });
}) 




// Code to Auto-Launch an App on Startup.
var AutoLaunch = require('auto-launch')
var myAppLauncher = new AutoLaunch({
  name: 'DHI Collab App'
})
myAppLauncher.enable();

myAppLauncher.isEnabled().then(function(isEnabled){
  if(isEnabled){
    return;
  }
  myAppLauncher.enable();
}).catch(function(err){
  console.log(err)
})




// MenuBar
// const template = [
  
// ]
// const menu = Menu.buildFromTemplate(template)
// Menu.setApplicationMenu(menu)