const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const connection = require('./database');
const User = connection.models.User;
const validatePassword = require('../lib/passwordUtils').validatePassword;

const customFields = {
    usernameField: 'uname',
    passwordField: 'pw',
};

const verifyCallback = (username, password, done)=>{
    User.findOne({username: username}).then((user)=>{
        // return check
        if(!user) {return done(null, false)}

        const isValid = validatePassword(password, user.hash, user.salt);

        if(isValid){
            return done(null, user);
        }else{
            return done(null, false);
        }
    }).catch((err)=>{
        done(err);
    });
}

const strategy = new LocalStrategy(customFields, verifyCallback);

passport.use(strategy)


// these two functions are used for expresssion sessions. Put user into the session or drag user out of the sessions. 
passport.serializeUser((user, done)=>{
    done(null, user.id);
});

passport.deserializeUser((userId, done)=>{
    User.findById(userId)
    .then((user)=>{
        done(null, user);
    })
    .catch(err=>done(err))
});
